const { test: base, expect } = require('@playwright/test');
const { images, pdf } = require('../../test-data/test-data');

const detailPath = /\/post\/[^/]+$/;
const editPath = /\/post\/edit\/[^/]+$/;

async function dismissSuccess(page, heading) {
  await expect(page.getByRole('dialog', { name: heading })).toBeVisible({ timeout: 60_000 });
  await page.getByRole('button', { name: 'OK', exact: true }).click();
}

async function openOwnProfileTab(page, tab) {
  await page.goto('/home');
  await page.getByRole('button', { name: 'เมนูผู้ใช้' }).click();
  await page.getByRole('link', { name: tab === 'drafts' ? 'แบบร่างของฉัน' : 'โปรไฟล์ของฉัน' }).click();
  await expect(page.getByRole('button', { name: 'โพสต์ของฉัน' })).toBeVisible();
  await page.getByRole('button', { name: tab === 'drafts' ? 'แบบร่าง' : 'โพสต์ของฉัน', exact: true }).click();
  await page.waitForLoadState('networkidle');
}

function draftCard(page, title) {
  const heading = page.getByRole('heading', { name: title, exact: true });
  return heading.locator('xpath=ancestor::*[.//button[contains(normalize-space(.), "แก้ไขโพสต์")]][1]');
}

async function openDraft(page, title) {
  await openOwnProfileTab(page, 'drafts');
  const card = draftCard(page, title);
  await expect(card).toBeVisible({ timeout: 15_000 });
  await card.getByRole('button', { name: 'แก้ไขโพสต์' }).click();
  await expect(page).toHaveURL(editPath);
  await expect(page.getByTestId('edit-post-title-input')).toHaveValue(title);
  return page.url();
}

async function openPost(page, title) {
  await openOwnProfileTab(page, 'posts');
  const heading = page.getByRole('heading', { name: title, exact: true });
  await expect(heading).toBeVisible({ timeout: 15_000 });
  await heading.click();
  await expect(page).toHaveURL(detailPath);
  await page.waitForLoadState('networkidle');
  await expect(page.getByRole('heading', { name: title, exact: true })).toBeVisible();
  return page.url();
}

async function openEditFromPost(page, title) {
  const postUrl = await openPost(page, title);
  await page.getByRole('link', { name: 'แก้ไขโพสต์', exact: true }).click();
  await expect(page).toHaveURL(editPath);
  await expect(page.getByTestId('edit-post-title-input')).toHaveValue(title);
  return { postUrl, editUrl: page.url() };
}

async function fillRequiredFields(page, { title, summary = 'สรุปเนื้อหาสำหรับทดสอบ', category = 'คณิตศาสตร์', withPdf = false } = {}) {
  const prefix = editPath.test(page.url()) ? 'edit-' : '';
  if (prefix && await page.getByTestId('remove-edit-cover-button').count()) {
    await page.getByTestId('remove-edit-cover-button').click();
  }
  await page.getByTestId(`${prefix}cover-file-input`).setInputFiles(images.coverJpg);
  await page.getByTestId(`${prefix}post-title-input`).fill(title);
  await page.getByTestId(`${prefix}education-level-select`).selectOption({ label: 'มัธยมศึกษาตอนปลาย' });
  await page.getByTestId(`${prefix}post-summary-input`).fill(summary);
  await page.getByTestId(`${prefix}category-tags-settings-button`).click();
  await page.getByTestId(`${prefix}category-select`).selectOption({ label: category });
  await page.getByRole('button', { name: 'เสร็จสิ้น' }).click();
  await page.getByTestId('post-content-input').locator('[contenteditable="true"]').fill('เนื้อหาตัวอย่างสำหรับทดสอบ TC-02');
  await page.getByTestId(`${prefix}supporting-images-file-input`).setInputFiles(images.image01);
  if (withPdf) await page.getByTestId(`${prefix}pdf-file-input`).setInputFiles(pdf.normal);
}

async function fillCompletePost(page, options) {
  await page.goto('/create');
  await expect(page.getByRole('heading', { name: 'สร้างโพสต์สรุปความรู้' })).toBeVisible();
  await fillRequiredFields(page, options);
}

async function publishPost(page, artifacts, options) {
  artifacts.track(options.title);
  await fillCompletePost(page, options);
  await page.getByTestId('publish-post-button').click();
  await dismissSuccess(page, 'โพสต์สำเร็จ!');
  const url = await openPost(page, options.title);
  artifacts.rememberUrl(options.title, url);
  return url;
}

async function saveDraft(page, artifacts, { title, summary }) {
  artifacts.track(title);
  await page.goto('/create');
  await expect(page.getByRole('heading', { name: 'สร้างโพสต์สรุปความรู้' })).toBeVisible();
  await page.getByTestId('post-title-input').fill(title);
  if (summary) await page.getByTestId('post-summary-input').fill(summary);
  await page.getByTestId('save-draft-button').click();
  await dismissSuccess(page, 'บันทึกสำเร็จ!');
  const url = await openDraft(page, title);
  artifacts.rememberUrl(title, url);
  return url;
}

async function deleteCurrentPost(page) {
  await page.getByRole('button', { name: 'ลบโพสต์' }).click();
  await expect(page.getByRole('dialog', { name: /คุณต้องการลบโพสต์/ })).toBeVisible();
  await page.getByRole('button', { name: 'ใช่, ลบเลย' }).click();
  await dismissSuccess(page, 'ลบสำเร็จ!');
}

async function cleanupTitle(page, item) {
  // Check both tabs because a failed publish can still have committed a draft or a post.
  for (const tab of ['posts', 'drafts']) {
    await openOwnProfileTab(page, tab);
    for (const title of item.aliases) {
      const heading = page.getByRole('heading', { name: title, exact: true });
      if (await heading.count()) {
        if (tab === 'drafts') {
          await draftCard(page, title).getByRole('button', { name: 'แก้ไขโพสต์' }).click();
          await expect(page).toHaveURL(editPath);
        } else {
          await heading.click();
          await expect(page).toHaveURL(detailPath);
          await page.waitForLoadState('networkidle');
        }
        item.url = page.url();
        await deleteCurrentPost(page);
        await openOwnProfileTab(page, tab);
      }
    }
    await openOwnProfileTab(page, tab);
    for (const title of item.aliases) {
      await expect(page.getByRole('heading', { name: title, exact: true })).toHaveCount(0);
    }
  }
  if (item.url) {
    await page.goto(item.url);
    await expect(page.getByRole('button', { name: 'ลบโพสต์' })).toHaveCount(0);
    await expect(page.getByRole('heading', { name: item.title, exact: true })).toHaveCount(0);
  }
}

const test = base.extend({
  artifacts: [async ({ page }, use) => {
    const items = [];
    const artifacts = {
      track(title) {
        if (!items.some((item) => item.aliases.includes(title))) items.push({ title, aliases: [title], url: '' });
      },
      rememberUrl(title, url) {
        const item = items.find((entry) => entry.title === title);
        if (!item) throw new Error(`Untracked post: ${title}`);
        item.url = url;
      },
      rename(oldTitle, newTitle) {
        const item = items.find((entry) => entry.aliases.includes(oldTitle));
        if (!item) throw new Error(`Untracked post: ${oldTitle}`);
        item.aliases.push(newTitle);
        item.title = newTitle;
      },
    };
    try {
      await use(artifacts);
    } finally {
      const failures = [];
      for (const item of [...items].reverse()) {
        try {
          await cleanupTitle(page, item);
        } catch (error) {
          failures.push(`${item.title} (${item.url || 'URL unknown'}): ${error.message}`);
        }
      }
      if (failures.length) throw new Error(`Test data cleanup failed:\n${failures.join('\n')}`);
      if (items.length) {
        await base.info().attach('created-posts-cleaned', {
          body: JSON.stringify(items), contentType: 'application/json',
        });
      }
    }
  }, { auto: true, timeout: 120_000 }],
});

module.exports = {
  test,
  expect,
  detailPath,
  editPath,
  fillCompletePost,
  fillRequiredFields,
  publishPost,
  saveDraft,
  openPost,
  openDraft,
  openEditFromPost,
  openOwnProfileTab,
  deleteCurrentPost,
};
